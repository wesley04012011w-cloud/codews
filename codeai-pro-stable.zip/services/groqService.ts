
// Fix: Migrated from Groq to Gemini API to resolve missing GROQ_CONFIG and align with project stack
import { GoogleGenAI } from "@google/genai";
import { Message } from '../types';
import { GEMINI_MODEL, SYSTEM_INSTRUCTION } from '../constants';

export const sendChatCompletion = async (messages: Message[]): Promise<string> => {
  // Fix: Initializing GoogleGenAI client using the required apiKey named parameter
  const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
  
  // Fix: Mapping conversation history to Gemini-compatible roles ('user' and 'model')
  const history = messages.slice(0, -1).map(m => ({
    role: m.role === 'user' ? 'user' : 'model',
    parts: [{ text: m.content }]
  }));

  const lastMessage = messages[messages.length - 1].content;

  try {
    // Fix: Using ai.models.generateContent for a direct request with model name and contents
    const response = await ai.models.generateContent({
      model: GEMINI_MODEL,
      contents: [
        ...history,
        { role: 'user', parts: [{ text: lastMessage }] }
      ],
      config: {
        systemInstruction: SYSTEM_INSTRUCTION,
        temperature: 0.7,
      },
    });

    // Fix: Accessing .text property directly as specified in the @google/genai SDK (not a method call)
    return response.text || "Desculpe, ocorreu um erro no processamento da resposta.";
  } catch (error) {
    console.error('Gemini Service Error:', error);
    throw error;
  }
};
