
import React, { useState, useEffect, useRef } from 'react';
import ReactMarkdown from 'react-markdown';
import remarkGfm from 'remark-gfm';
import { Message, ChatSession, AccessKey } from './types';
import { 
  LOCAL_STORAGE_KEY_CHATS, 
  LOCAL_STORAGE_KEY_KEYS, 
  INITIAL_ADMIN_KEY 
} from './constants';
import { sendChatCompletionStream } from './services/geminiService';

const CodeBlock = (props: any) => {
  const { children, className } = props;
  const [copied, setCopied] = useState(false);
  const codeString = String(children).replace(/\n$/, '');

  const handleCopy = () => {
    navigator.clipboard.writeText(codeString).then(() => {
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    });
  };

  return (
    <div className="group relative my-6 rounded-2xl overflow-hidden border border-white/5 bg-[#0d1117] shadow-2xl">
      <div className="flex items-center justify-between px-5 py-3 bg-white/[0.03] border-b border-white/5">
        <div className="flex items-center gap-2">
            <div className="flex gap-1.5">
                <div className="w-2.5 h-2.5 rounded-full bg-red-500/30 border border-red-500/50"></div>
                <div className="w-2.5 h-2.5 rounded-full bg-yellow-500/30 border border-yellow-500/50"></div>
                <div className="w-2.5 h-2.5 rounded-full bg-green-500/30 border border-green-500/50"></div>
            </div>
            <span className="ml-3 text-[10px] font-mono text-slate-500 uppercase tracking-widest">{className?.replace('language-', '') || 'code'}</span>
        </div>
        <button onClick={handleCopy} className="text-[10px] text-slate-400 hover:text-white transition-all flex items-center gap-2 uppercase font-bold px-3 py-1.5 rounded-lg hover:bg-white/10">
          {copied ? (
              <>
                <svg xmlns="http://www.w3.org/2000/svg" className="h-3 w-3 text-green-400" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={3} d="M5 13l4 4L19 7" /></svg>
                Copiado
              </>
          ) : 'Copiar'}
        </button>
      </div>
      <pre className="p-6 overflow-x-auto custom-scrollbar">
        <code className={`${className} font-mono text-sm leading-relaxed text-slate-300`}>{children}</code>
      </pre>
    </div>
  );
};

const App: React.FC = () => {
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [isAdmin, setIsAdmin] = useState(false);
  const [accessKeyInput, setAccessKeyInput] = useState('');
  const [authError, setAuthError] = useState('');
  const [isSidebarOpen, setIsSidebarOpen] = useState(false);
  const [sessions, setSessions] = useState<ChatSession[]>([]);
  const [activeSessionId, setActiveSessionId] = useState<string | null>(null);
  const [input, setInput] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [showAdminPanel, setShowAdminPanel] = useState(false);
  const [adminTab, setAdminTab] = useState<'keys' | 'files'>('keys');
  const [keys, setKeys] = useState<AccessKey[]>([]);
  const [newKeyLabel, setNewKeyLabel] = useState('');

  const scrollRef = useRef<HTMLDivElement>(null);
  const endOfMessagesRef = useRef<HTMLDivElement>(null);

  const projectFiles = [
    { name: 'App.tsx', desc: 'Interface principal, lógica de chat e painel administrativo.' },
    { name: 'index.html', desc: 'Estrutura HTML base e carregamento de estilos/fontes.' },
    { name: 'constants.ts', desc: 'Configurações de modelo e instrução de sistema da IA.' },
    { name: 'services/geminiService.ts', desc: 'Conexão com a API do Google Gemini (Streaming).' },
    { name: 'types.ts', desc: 'Definições de tipos TypeScript (Mensagens, Chaves, Sessões).' },
    { name: 'index.tsx', desc: 'Ponto de entrada do React.' },
    { name: 'metadata.json', desc: 'Metadados da aplicação.' },
    { name: 'GUIA_DO_PROJETO.md', desc: 'Documentação de auxílio.' }
  ];

  useEffect(() => {
    const savedSessions = localStorage.getItem(LOCAL_STORAGE_KEY_CHATS);
    if (savedSessions) setSessions(JSON.parse(savedSessions));

    const savedKeys = localStorage.getItem(LOCAL_STORAGE_KEY_KEYS);
    let currentKeys: AccessKey[] = [];
    
    if (savedKeys) {
      currentKeys = JSON.parse(savedKeys);
    } else {
      currentKeys = [{
        id: '1',
        key: INITIAL_ADMIN_KEY,
        label: 'Admin Master',
        createdAt: Date.now(),
        isAdmin: true,
        uses: 0
      }];
    }
    
    setKeys(currentKeys);
    localStorage.setItem(LOCAL_STORAGE_KEY_KEYS, JSON.stringify(currentKeys));

    const authed = sessionStorage.getItem('is_authed');
    if (authed === 'true') {
      setIsAuthenticated(true);
      setIsAdmin(sessionStorage.getItem('is_admin') === 'true');
    }
  }, []);

  useEffect(() => {
    localStorage.setItem(LOCAL_STORAGE_KEY_CHATS, JSON.stringify(sessions));
    if (endOfMessagesRef.current) {
        endOfMessagesRef.current.scrollIntoView({ behavior: 'smooth' });
    }
  }, [sessions]);

  useEffect(() => {
    localStorage.setItem(LOCAL_STORAGE_KEY_KEYS, JSON.stringify(keys));
  }, [keys]);

  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    const cleanInput = accessKeyInput.trim();
    
    if (cleanInput === INITIAL_ADMIN_KEY) {
      setIsAuthenticated(true);
      setIsAdmin(true);
      sessionStorage.setItem('is_authed', 'true');
      sessionStorage.setItem('is_admin', 'true');
      return;
    }

    const foundKey = keys.find(k => k.key === cleanInput);
    if (foundKey) {
      setIsAuthenticated(true);
      setIsAdmin(foundKey.isAdmin);
      sessionStorage.setItem('is_authed', 'true');
      sessionStorage.setItem('is_admin', String(foundKey.isAdmin));
      const updatedKeys = keys.map(k => k.id === foundKey.id ? { ...k, uses: k.uses + 1 } : k);
      setKeys(updatedKeys);
    } else {
      setAuthError('Chave de acesso inválida.');
    }
  };

  const activeSession = sessions.find(s => s.id === activeSessionId);

  const startNewChat = (initialPrompt?: string) => {
    const newId = Date.now().toString();
    const newSession: ChatSession = {
      id: newId,
      title: initialPrompt ? initialPrompt.slice(0, 30) + '...' : 'Novo Chat',
      messages: [],
      lastActive: Date.now()
    };
    setSessions([newSession, ...sessions]);
    setActiveSessionId(newId);
    setIsSidebarOpen(false);
    if (initialPrompt) {
        setTimeout(() => setInput(initialPrompt), 100);
    }
  };

  const deleteSession = (e: React.MouseEvent, id: string) => {
    e.stopPropagation();
    setSessions(sessions.filter(s => s.id !== id));
    if (activeSessionId === id) setActiveSessionId(null);
  };

  const handleSend = async (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    if (!input.trim() || isLoading) return;

    let currentSessionId = activeSessionId;
    let currentSessions = [...sessions];

    if (!currentSessionId) {
      const newId = Date.now().toString();
      const newSession: ChatSession = {
        id: newId,
        title: input.slice(0, 30) + '...',
        messages: [],
        lastActive: Date.now()
      };
      currentSessions = [newSession, ...currentSessions];
      setSessions(currentSessions);
      setActiveSessionId(newId);
      currentSessionId = newId;
    }

    const userMsg: Message = { role: 'user', content: input, timestamp: Date.now() };
    const updatedSessions = currentSessions.map(s => {
      if (s.id === currentSessionId) {
        return {
          ...s,
          messages: [...s.messages, userMsg],
          lastActive: Date.now(),
          title: s.messages.length === 0 ? input.slice(0, 30) : s.title
        };
      }
      return s;
    });

    setSessions(updatedSessions);
    setInput('');
    setIsLoading(true);

    const assistantPlaceholder: Message = { role: 'assistant', content: '', timestamp: Date.now() };
    setSessions(prev => prev.map(s => s.id === currentSessionId ? { ...s, messages: [...s.messages, assistantPlaceholder] } : s));

    try {
      const targetSession = updatedSessions.find(s => s.id === currentSessionId);
      if (targetSession) {
        await sendChatCompletionStream(targetSession.messages, (fullText) => {
          setSessions(prev => prev.map(s => s.id === currentSessionId ? {
            ...s,
            messages: s.messages.map((m, i) => i === s.messages.length - 1 ? { ...m, content: fullText } : m)
          } : s));
        });
      }
    } catch (err) {
      console.error(err);
    } finally {
      setIsLoading(false);
    }
  };

  const generateKey = () => {
    if (!newKeyLabel.trim()) return;
    const newKey: AccessKey = {
      id: Math.random().toString(36).substr(2, 9),
      key: `CODE-${Math.random().toString(36).substr(2, 6).toUpperCase()}`,
      label: newKeyLabel,
      createdAt: Date.now(),
      isAdmin: false,
      uses: 0
    };
    setKeys([...keys, newKey]);
    setNewKeyLabel('');
  };

  const deleteKey = (id: string) => {
    setKeys(keys.filter(k => k.id !== id));
  };

  if (!isAuthenticated) {
    return (
      <div className="h-screen w-screen bg-[#0b0e14] flex items-center justify-center p-6 bg-[radial-gradient(circle_at_center,_var(--tw-gradient-stops))] from-cyan-950/10 via-transparent to-transparent">
        <div className="max-w-md w-full bg-[#0f131a] border border-white/5 rounded-[48px] p-12 shadow-[0_25px_60px_rgba(0,0,0,0.6)] animate-in zoom-in duration-700">
          <div className="w-24 h-24 rounded-[32px] bg-gradient-to-br from-cyan-400 to-indigo-600 flex items-center justify-center mb-10 mx-auto shadow-[0_0_40px_rgba(34,211,238,0.25)] ring-4 ring-cyan-400/10">
            <svg xmlns="http://www.w3.org/2000/svg" className="h-12 w-12 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M10 20l4-16m4 4l4 4-4 4M6 16l-4-4 4-4" />
            </svg>
          </div>
          <h2 className="text-4xl font-black text-center text-white mb-2 tracking-tighter">CodeAI Pro</h2>
          <p className="text-slate-500 text-center text-sm mb-12 font-medium tracking-tight">Ambiente de desenvolvimento de alta performance.</p>
          <form onSubmit={handleLogin} className="space-y-6">
            <input 
              type="password"
              placeholder="Digite sua chave mestre"
              value={accessKeyInput}
              onChange={(e) => setAccessKeyInput(e.target.value)}
              className="w-full bg-white/[0.03] border border-white/10 rounded-[22px] px-8 py-5 text-white placeholder:text-slate-600 focus:outline-none focus:border-cyan-500/50 focus:bg-white/[0.05] transition-all text-center tracking-[0.3em]"
            />
            {authError && <p className="text-red-400 text-xs text-center font-bold tracking-tight">{authError}</p>}
            <button type="submit" className="w-full bg-cyan-500 hover:bg-cyan-400 text-black font-black py-5 rounded-[22px] transition-all transform hover:scale-[1.03] active:scale-[0.97] shadow-2xl shadow-cyan-500/20 uppercase tracking-widest text-xs">
              Autenticar Sistema
            </button>
          </form>
          <div className="mt-14 pt-8 border-t border-white/5">
             <p className="text-[10px] text-slate-700 text-center uppercase tracking-[0.3em] font-black">Stable Build • Gemini 2.5 Flash</p>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="flex h-screen bg-[#0b0e14] text-slate-200 overflow-hidden font-sans relative">
      {isSidebarOpen && (
        <div className="fixed inset-0 bg-black/80 backdrop-blur-md z-40 lg:hidden animate-in fade-in duration-300" onClick={() => setIsSidebarOpen(false)} />
      )}

      <aside className={`
        fixed inset-y-0 left-0 z-50 w-[300px] bg-[#090c10] border-r border-white/5 flex flex-col transition-all duration-500 ease-[cubic-bezier(0.4, 0, 0.2, 1)]
        lg:relative lg:translate-x-0 ${isSidebarOpen ? 'translate-x-0' : '-translate-x-full lg:translate-x-0'}
      `}>
        <div className="p-8 border-b border-white/5 flex items-center justify-between">
          <div className="flex items-center gap-4">
            <div className="w-10 h-10 rounded-2xl bg-gradient-to-br from-cyan-500 to-indigo-600 flex items-center justify-center font-black text-white text-sm shadow-xl shadow-cyan-500/10">C</div>
            <span className="font-black text-sm tracking-tighter uppercase text-white/90">CodeAI Pro</span>
          </div>
          <div className="flex items-center gap-2">
            {isAdmin && (
              <button onClick={() => setShowAdminPanel(true)} className="p-2.5 hover:bg-white/5 rounded-xl text-slate-500 hover:text-cyan-400 transition-all">
                <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 6V4m0 2a2 2 0 100 4m0-4a2 2 0 110 4m-6 8a2 2 0 100-4m0 4a2 2 0 110-4m0 4v2m0-6V4m6 6v10m6-2a2 2 0 100-4m0 4a2 2 0 110-4m0 4v2m0-6V4" /></svg>
              </button>
            )}
            <button onClick={() => setIsSidebarOpen(false)} className="lg:hidden p-2.5 hover:bg-white/5 rounded-xl text-slate-500">
              <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2.5} d="M15 19l-7-7 7-7" /></svg>
            </button>
          </div>
        </div>

        <div className="p-6">
          <button onClick={() => startNewChat()} className="w-full flex items-center justify-center gap-3 px-6 py-4 rounded-[22px] bg-white/[0.04] border border-white/10 hover:border-cyan-500/40 hover:bg-white/[0.06] transition-all text-xs font-black uppercase tracking-widest text-slate-200">
            <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4 text-cyan-400" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={3} d="M12 4v16m8-8H4" /></svg>
            Novo Projeto
          </button>
        </div>

        <div className="flex-1 overflow-y-auto px-4 space-y-1.5 custom-scrollbar">
          <p className="px-4 text-[10px] font-black text-slate-600 uppercase tracking-[0.3em] mb-4 mt-8">Histórico de Sessões</p>
          {sessions.length === 0 && <p className="px-4 text-[10px] text-slate-700 italic">Nenhum chat salvo.</p>}
          {sessions.map(s => (
            <div key={s.id} onClick={() => { setActiveSessionId(s.id); setIsSidebarOpen(false); }} className={`group w-full text-left px-5 py-4 rounded-[20px] text-sm transition-all flex items-center gap-3 cursor-pointer ${activeSessionId === s.id ? 'bg-cyan-500/10 text-cyan-400 border border-cyan-500/20' : 'text-slate-500 hover:bg-white/[0.03] hover:text-slate-300'}`}>
              <svg xmlns="http://www.w3.org/2000/svg" className={`h-4 w-4 shrink-0 ${activeSessionId === s.id ? 'text-cyan-400' : 'text-slate-700'}`} fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M7 21h10a2 2 0 002-2V9.414a1 1 0 00-.293-.707l-5.414-5.414A1 1 0 0012.586 3H7a2 2 0 00-2 2v14a2 2 0 002 2z" /></svg>
              <span className="truncate flex-1 font-semibold">{s.title}</span>
              <button onClick={(e) => deleteSession(e, s.id)} className="opacity-0 lg:group-hover:opacity-100 p-1.5 hover:bg-red-500/10 hover:text-red-400 rounded-lg transition-all"><svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" /></svg></button>
            </div>
          ))}
        </div>

        <div className="p-6 border-t border-white/5 bg-black/20">
          <button onClick={() => { sessionStorage.clear(); window.location.reload(); }} className="w-full flex items-center gap-3 px-6 py-4 rounded-2xl hover:bg-red-500/5 text-slate-600 hover:text-red-500 transition-all text-xs font-black uppercase tracking-[0.2em]">
            <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M17 16l4-4m0 0l-4-4m4 4H7m6 4v1a3 3 0 01-3 3H6a3 3 0 01-3-3V7a3 3 0 013-3h4a3 3 0 013 3v1" /></svg>
            Desconectar
          </button>
        </div>
      </aside>

      <main className="flex-1 flex flex-col relative bg-[#0b0e14] w-full shadow-[inset_1px_0_0_0_rgba(255,255,255,0.05)]">
        <header className="lg:hidden flex items-center justify-between p-6 bg-[#090c10]/80 backdrop-blur-2xl border-b border-white/5 sticky top-0 z-30">
          <div className="flex items-center gap-4">
            <button onClick={() => setIsSidebarOpen(true)} className="p-3 bg-cyan-500/10 rounded-2xl text-cyan-400 border border-cyan-500/20 active:scale-90 transition-transform">
              <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2.5} d="M13 5l7 7-7 7" /></svg>
            </button>
            <span className="font-black text-xs tracking-[0.2em] text-white/70 uppercase">CodeAI Pro</span>
          </div>
          <button onClick={() => startNewChat()} className="p-3 text-slate-500 hover:text-white bg-white/5 rounded-2xl">
            <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 4v16m8-8H4" /></svg>
          </button>
        </header>

        <div className="flex-1 overflow-y-auto custom-scrollbar scroll-smooth">
          {!activeSessionId ? (
            <div className="h-full flex flex-col items-center justify-center p-8 max-w-4xl mx-auto text-center">
              <div className="w-28 h-28 rounded-[40px] bg-gradient-to-br from-cyan-500/20 to-indigo-600/20 border border-cyan-500/30 flex items-center justify-center text-cyan-400 shadow-[0_0_60px_rgba(6,182,212,0.15)] mb-12 animate-pulse">
                <svg xmlns="http://www.w3.org/2000/svg" className="h-14 w-14" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M8 9l3 3-3 3m5 0h3M5 20h14a2 2 0 002-2V6a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z" /></svg>
              </div>
              <h1 className="text-5xl font-black text-white mb-6 tracking-tighter leading-tight">Como posso ajudar na sua <span className="text-cyan-500 underline decoration-cyan-500/20 underline-offset-8">jornada de código?</span></h1>
              <p className="text-slate-400 text-xl font-medium mb-12 max-w-2xl leading-relaxed">Selecione uma categoria abaixo ou simplesmente descreva seu desafio técnico.</p>
              
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4 w-full max-w-2xl text-left">
                  {[
                      { icon: '🚀', text: 'Criar uma API REST em Python', prompt: 'Crie uma API REST completa usando FastAPI e Python com autenticação JWT.' },
                      { icon: '🎨', text: 'Landing Page com Tailwind', prompt: 'Desenvolva o código de uma landing page moderna para SaaS usando React e Tailwind CSS.' },
                      { icon: '🛡️', text: 'Script de Segurança em Lua', prompt: 'Escreva um sistema de permissões seguro para Roblox em Lua.' },
                      { icon: '⚡', text: 'Otimização de Algoritmo C++', prompt: 'Otimize este algoritmo de ordenação em C++ para melhor performance de memória.' }
                  ].map((item, i) => (
                      <button key={i} onClick={() => startNewChat(item.prompt)} className="p-6 bg-white/[0.03] border border-white/5 rounded-3xl text-left hover:bg-white/[0.06] hover:border-cyan-500/30 transition-all group">
                          <span className="text-2xl mb-4 block">{item.icon}</span>
                          <p className="text-slate-200 font-bold group-hover:text-cyan-400 transition-colors">{item.text}</p>
                      </button>
                  ))}
              </div>
            </div>
          ) : (
            <div className="max-w-4xl mx-auto py-12 lg:py-20 px-6 lg:px-10 space-y-16">
              {activeSession?.messages.map((msg, idx) => (
                <div key={idx} className={`flex ${msg.role === 'user' ? 'justify-end' : 'justify-start'} animate-in slide-in-from-bottom-4 duration-500`}>
                  <div className={`flex gap-5 lg:gap-8 max-w-[98%] lg:max-w-[90%] ${msg.role === 'user' ? 'flex-row-reverse' : ''}`}>
                    <div className={`w-10 h-10 lg:w-12 lg:h-12 shrink-0 rounded-[18px] lg:rounded-[22px] flex items-center justify-center font-black text-xs lg:text-sm ${msg.role === 'user' ? 'bg-cyan-500 text-black shadow-xl shadow-cyan-500/20' : 'bg-white/[0.06] border border-white/10 text-cyan-400'}`}>
                        {msg.role === 'user' ? 'U' : 'AI'}
                    </div>
                    <div className={`p-6 lg:p-8 rounded-[28px] lg:rounded-[36px] text-base lg:text-lg leading-relaxed ${msg.role === 'user' ? 'bg-cyan-500/10 border border-cyan-500/20 text-white rounded-tr-none' : 'bg-[#161b24] border border-white/5 text-slate-200 rounded-tl-none shadow-2xl'}`}>
                      <ReactMarkdown remarkPlugins={[remarkGfm]} components={{ code: CodeBlock }} className="prose prose-invert prose-base lg:prose-lg max-w-none prose-pre:bg-transparent prose-pre:p-0 prose-code:text-cyan-300">
                        {msg.content || '...'}
                      </ReactMarkdown>
                    </div>
                  </div>
                </div>
              ))}
              <div ref={endOfMessagesRef} />
            </div>
          )}
        </div>

        <div className="p-6 lg:p-12 bg-gradient-to-t from-[#0b0e14] via-[#0b0e14]/95 to-transparent">
          <form onSubmit={handleSend} className="max-w-4xl mx-auto relative group">
            <div className="absolute -inset-1 bg-gradient-to-r from-cyan-400 to-indigo-600 rounded-[34px] lg:rounded-[44px] blur opacity-0 group-focus-within:opacity-20 transition duration-1000"></div>
            <div className="relative flex items-center bg-[#161b24] border border-white/10 rounded-[28px] lg:rounded-[38px] p-2 lg:p-3 pl-8 lg:pl-12 focus-within:border-cyan-500/50 focus-within:bg-[#1a222e] transition-all shadow-[0_15px_40px_rgba(0,0,0,0.4)]">
              <input 
                value={input} 
                onChange={(e) => setInput(e.target.value)} 
                placeholder="Cole seu código ou descreva seu problema..." 
                disabled={isLoading} 
                className="flex-1 bg-transparent border-none outline-none text-base lg:text-lg text-white py-4 lg:py-5 placeholder:text-slate-600" 
              />
              <button 
                type="submit" 
                disabled={isLoading || !input.trim()} 
                className="ml-6 p-4 lg:p-6 rounded-[22px] lg:rounded-[30px] bg-gradient-to-br from-cyan-400 to-indigo-600 text-white disabled:opacity-30 transition-all shadow-xl shadow-cyan-900/40 hover:scale-[1.05] active:scale-95"
              >
                {isLoading ? <div className="h-6 w-6 border-4 border-white/20 border-t-white rounded-full animate-spin" /> : <svg xmlns="http://www.w3.org/2000/svg" className="h-7 w-7" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={3} d="M14 5l7 7-7 7M5 5l7 7-7 7" /></svg>}
              </button>
            </div>
          </form>
          <div className="flex items-center justify-center gap-6 mt-6">
              <span className="text-[10px] text-slate-700 font-black uppercase tracking-[0.4em]">v2.5 Stable</span>
              <div className="h-1 w-1 rounded-full bg-slate-800"></div>
              <span className="text-[10px] text-slate-700 font-black uppercase tracking-[0.4em]">Engine: Gemini 3 Flash</span>
          </div>
        </div>
      </main>

      {showAdminPanel && (
        <div className="fixed inset-0 z-[60] flex items-center justify-center p-6 lg:p-14 bg-black/95 backdrop-blur-2xl animate-in fade-in duration-500">
          <div className="w-full max-w-3xl bg-[#0f131a] border border-white/10 rounded-[56px] shadow-[0_0_120px_rgba(0,0,0,1)] flex flex-col max-h-[90vh] overflow-hidden">
            <div className="p-10 lg:p-14 border-b border-white/5 flex items-center justify-between bg-gradient-to-r from-transparent to-cyan-500/5">
              <div>
                  <h2 className="text-3xl font-black text-white flex items-center gap-5">
                    <div className="p-3 bg-cyan-500/10 rounded-2xl text-cyan-400 border border-cyan-500/20"><svg xmlns="http://www.w3.org/2000/svg" className="h-8 w-8" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12l2 2 4-4m5.618-4.016A11.955 11.955 0 0112 2.944a11.955 11.955 0 01-8.618 3.04A12.02 12.02 0 003 9c0 5.591 3.824 10.29 9 11.622 5.176-1.332 9-6.03 9-11.622 0-1.042-.133-2.052-.382-3.016z" /></svg></div>
                    Configurações do Sistema
                  </h2>
                  <p className="text-slate-500 text-base mt-2 font-medium">Gerencie chaves e explore a estrutura do projeto.</p>
              </div>
              <button onClick={() => setShowAdminPanel(false)} className="p-4 hover:bg-white/5 rounded-3xl text-slate-600 hover:text-white transition-all"><svg xmlns="http://www.w3.org/2000/svg" className="h-8 w-8" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" /></svg></button>
            </div>
            
            <div className="flex px-10 pt-6 gap-8 border-b border-white/5">
                <button onClick={() => setAdminTab('keys')} className={`pb-4 text-xs font-black uppercase tracking-widest transition-all border-b-2 ${adminTab === 'keys' ? 'border-cyan-500 text-cyan-400' : 'border-transparent text-slate-600 hover:text-slate-400'}`}>Chaves de Acesso</button>
                <button onClick={() => setAdminTab('files')} className={`pb-4 text-xs font-black uppercase tracking-widest transition-all border-b-2 ${adminTab === 'files' ? 'border-cyan-500 text-cyan-400' : 'border-transparent text-slate-600 hover:text-slate-400'}`}>Explorador de Projeto</button>
            </div>

            <div className="p-10 lg:p-14 overflow-y-auto space-y-12 custom-scrollbar">
              {adminTab === 'keys' ? (
                  <>
                    <div className="space-y-4">
                        <p className="text-xs font-black text-slate-600 uppercase tracking-[0.3em]">Gerar Nova Chave</p>
                        <div className="flex flex-col md:flex-row gap-5">
                            <input value={newKeyLabel} onChange={(e) => setNewKeyLabel(e.target.value)} placeholder="Nome do desenvolvedor ou projeto..." className="flex-1 bg-white/[0.04] border border-white/10 rounded-[24px] px-8 py-5 text-base focus:outline-none focus:border-cyan-500 transition-all shadow-inner" />
                            <button onClick={generateKey} className="bg-white text-black px-10 py-5 rounded-[24px] font-black text-xs uppercase tracking-widest hover:bg-cyan-400 transition-all shadow-xl shadow-white/5">Criar Licença</button>
                        </div>
                    </div>

                    <div className="space-y-6">
                        <p className="text-xs font-black text-slate-600 uppercase tracking-[0.3em]">Gerenciamento de Licenças Ativas</p>
                        <div className="grid gap-4">
                            {keys.map(k => (
                            <div key={k.id} className="bg-white/[0.02] border border-white/5 rounded-[32px] p-8 flex items-center justify-between group hover:bg-white/[0.05] hover:border-white/10 transition-all">
                                <div className="space-y-3">
                                <div className="flex items-center gap-4">
                                    <span className="text-lg font-black text-white">{k.label}</span>
                                    {k.isAdmin && <span className="text-[10px] bg-cyan-400/20 text-cyan-400 px-3 py-1 rounded-full font-black uppercase tracking-widest border border-cyan-400/30">Master Access</span>}
                                </div>
                                <div className="flex items-center gap-3">
                                    <code className="text-sm text-cyan-500 font-black font-mono bg-cyan-500/10 px-4 py-2 rounded-xl border border-cyan-500/10 block">{k.key}</code>
                                    <button onClick={() => navigator.clipboard.writeText(k.key)} className="text-[10px] text-slate-600 hover:text-cyan-400 font-black uppercase tracking-widest transition-colors">Copiar</button>
                                </div>
                                </div>
                                <div className="flex items-center gap-8 lg:gap-14">
                                <div className="text-right">
                                    <p className="text-[10px] text-slate-600 uppercase font-black tracking-widest mb-1">Requisições</p>
                                    <p className="text-3xl font-black text-white tabular-nums tracking-tighter">{k.uses}</p>
                                </div>
                                {!k.isAdmin && (
                                    <button onClick={() => deleteKey(k.id)} className="p-4 text-slate-700 hover:text-red-400 hover:bg-red-400/10 rounded-2xl transition-all"><svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-4v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16" /></svg></button>
                                )}
                                </div>
                            </div>
                            ))}
                        </div>
                    </div>
                  </>
              ) : (
                  <div className="space-y-8 animate-in fade-in duration-300">
                    <p className="text-xs font-black text-slate-600 uppercase tracking-[0.3em]">Arquivos do Projeto</p>
                    <div className="grid gap-4">
                        {projectFiles.map((file, i) => (
                            <div key={i} className="flex items-start gap-6 p-6 bg-white/[0.02] border border-white/5 rounded-3xl hover:border-cyan-500/20 transition-all">
                                <div className="p-4 bg-white/5 rounded-2xl text-cyan-400">
                                    <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" /></svg>
                                </div>
                                <div className="space-y-1">
                                    <h4 className="font-bold text-slate-200">{file.name}</h4>
                                    <p className="text-sm text-slate-500">{file.desc}</p>
                                </div>
                            </div>
                        ))}
                    </div>
                    <div className="p-8 bg-cyan-500/5 border border-cyan-500/20 rounded-[32px] mt-10">
                        <h5 className="text-cyan-400 font-black text-xs uppercase tracking-widest mb-3">Onde encontrar fisicamente?</h5>
                        <p className="text-sm text-slate-400 leading-relaxed">Estes arquivos estão localizados na <b>barra lateral esquerda do seu editor</b> nesta plataforma. Se estiver usando um computador, procure por um ícone de pasta 📁 para expandir a lista de arquivos e editar o código diretamente.</p>
                    </div>
                  </div>
              )}
            </div>
            
            <div className="p-10 border-t border-white/5 bg-black/40">
              <p className="text-[11px] text-slate-600 text-center uppercase tracking-[0.3em] font-black italic">Build v2.5 Stable • Publicação Autorizada</p>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default App;
