
# 🚀 Guia do Projeto CodeAI Pro v2.5

Este arquivo serve como um mapa para você localizar e gerenciar seu aplicativo.

## 📂 Estrutura de Arquivos
Todos estes arquivos estão no seu explorador lateral:

1.  **`index.html`**: Onde carregamos as fontes (Inter e JetBrains Mono) e o Tailwind CSS.
2.  **`App.tsx`**: O arquivo principal. Contém o Chat, o Painel Admin e a tela de Login.
3.  **`constants.ts`**: Configurações globais. 
    *   **Senha Master:** `ADMIN-PRO-2025`
    *   **Instrução do Sistema:** Define como a IA deve se comportar.
4.  **`services/geminiService.ts`**: Gerencia a comunicação em tempo real (Streaming) com a API do Google Gemini.
5.  **`types.ts`**: Define a estrutura de dados (Mensagens, Sessões, Chaves).
6.  **`metadata.json`**: Informações básicas do app.

## 🔑 Como usar o App
1.  Abra o Preview.
2.  Digite a chave: `ADMIN-PRO-2025`.
3.  No ícone de engrenagem (Configurações/Admin), você pode gerar novas chaves para amigos ou clientes.
4.  Todas as conversas e chaves ficam salvas no seu navegador (LocalStorage).

## 🌐 Publicação Externa
Se quiser colocar esse site no ar (Vercel, Netlify ou GitHub Pages):
1.  Copie o conteúdo de cada arquivo para uma pasta local.
2.  Certifique-se de ter uma conta no Google AI Studio para usar sua própria API Key se for rodar fora deste ambiente.
    