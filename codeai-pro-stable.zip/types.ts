
export type Role = 'system' | 'user' | 'model' | 'assistant';

export interface Message {
  role: Role;
  content: string;
  timestamp: number;
}

export interface ChatSession {
  id: string;
  title: string;
  messages: Message[];
  lastActive: number;
}

export interface AccessKey {
  id: string;
  key: string;
  label: string;
  createdAt: number;
  isAdmin: boolean;
  uses: number;
}
